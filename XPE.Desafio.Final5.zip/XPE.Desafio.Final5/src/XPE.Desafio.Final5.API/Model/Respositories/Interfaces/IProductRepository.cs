﻿using XPE.Desafio.Final5.API.Model.Domains;

namespace XPE.Desafio.Final5.API.Model.Respositories.Interfaces
{
    public interface IProductRepository : IDefaultRepository<Product>
    {
    }
}
