﻿using XPE.Desafio.Final5.API.Model.Respositories.Interfaces;

namespace XPE.Desafio.Final5.API.Model.Services.Interfaces
{
    public interface IProductService : IProductRepository
    {        
    }
}
